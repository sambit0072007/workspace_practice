package com.example.demo.model;

import lombok.Data;

@Data
public class NewBus {

	private String busOwner;
	private String busName;
	private String busNumber;
	private String login;
	private String password;
	
}
