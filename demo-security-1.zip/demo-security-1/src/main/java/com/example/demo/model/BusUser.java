package com.example.demo.model;

import lombok.Data;

@Data
public class BusUser {
	private String login;
	private String password;
	

}
